#SITE-sh

from os import times
import socket
#connect to ip and check if open
import threading
#
import concurrent.futures
#scan port after port

print_lock = threading.Lock()
print("------------------")
print("Easy Port Scanner")
print("------------------")
print("\n")

ip1 = input('Enter IP / URL to scan: ')
ip = socket.gethostbyname(ip1)
def scan(ip, port):
    #                              IPV4            TCP
    scanner = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    scanner.settimeout(2)
    try:
        scanner.connect((ip, port))
        scanner.close()
        with print_lock:
            print(f"[{port}]" + " OPENED")
        
    except:
        pass
with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
    for port in range(1000):
        executor.submit(scan, ip, port+1)

